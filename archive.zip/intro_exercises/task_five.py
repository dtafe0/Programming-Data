tn = str(147103)

a = int(tn[:-1]) % 7 

print(a)
print(tn[5])
print(a==int(tn[5]))

