
minutes = 197
hours = minutes // 60
mins = minutes % 60
print(minutes, "minutes becomes", hours, "hrs", mins, "mins")