

length = 15
width = 25
floorspace = length * width
print("The floorspace has an area of ", floorspace, "m2")
