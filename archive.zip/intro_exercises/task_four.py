

F = 234
C = (F-32)*5/9

print( "Fahrenheit:", F)
print( "Celsius:", C)