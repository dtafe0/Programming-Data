
myNewList = list()
i=48
while i >=48 and i <= 122 :
    myNewList.append(chr(i))
    # Printing on a single line with the print() function
    print(myNewList[i - 48], sep=" ", end=" ", flush=True)
    i += 1

primeNumbers =    [2, 3, 5, 7, 11, 13, 17, 19]
oddNumbers =    [1, 3, 5, 7, 9, 11, 13, 15]
magicNumbers = [12, 42]
magicNumbers.insert(1,21)

index12=magicNumbers.index(42)
magicNumbers.remove(magicNumbers[index12])

print(primeNumbers[1:7]+oddNumbers)
primeNumbers.reverse()
print(primeNumbers)
print(magicNumbers)

for itm in range(3,len(oddNumbers),2) :
    print(itm, oddNumbers[itm])

    