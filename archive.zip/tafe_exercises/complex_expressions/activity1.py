# Write a Python program that asks the user to enter their name and their age. Then show the user a message indicating the year that the user will turn 100 years old.
from datetime import datetime

name = input("enter your name:")
age = input("enter your age:")

years2century = 100-int(age)

centurion = datetime.now().year + years2century

print("you will turn 100 at the year", centurion)

